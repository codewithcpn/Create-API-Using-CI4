<?php

namespace App\Models;
use CodeIgniter\Model;

class AlexaModel extends Model
{ 
    protected $db2;
    function __construct(){ 
	  $this->db3 = \Config\Database::connect('alexa');
	} 
	
	/**
	 *  Get Single record
	 */ 
    function getSingleData($columns, $table, $where = []){
        $builder = $this->db3->table($table);
        $builder->select($columns)->where($where);
	    return $builder->get()->getRow();
    }
    
    /**
     * Get all record
     */
    public function getAllRecord($columns, $table){
        $builder = $this->db3->table($table);
        $builder->select($columns);
        return $builder->get()->getResult();
    }   
    
    
    /**
     * Insert Record
     */
    public function insertData($table, $data)
    {
        return $this->db3->table($table)->insert($data);
    }   
    
    /**
      * Get AllRecord with where condition or order by
    */ 
    public function getAllRecordWhereOrderDirection($columns, $table, $where = null, $orderBy = null) {
        $builder = $this->db3->table($table);
        $builder->select($columns);
        if ($where !== null) {
            $builder->where($where);
        }
        if ($orderBy !== null && is_array($orderBy)) {
            foreach ($orderBy as $column => $direction) {
                $builder->orderBy($column, $direction);
            }
        }
        return $builder->get()->getResult();
    }
    
    
    /**
     * 
     */     
    public function updateData($table, $data, $where)
    {
        $builder = $this->db3->table($table);
        return $builder->where($where)->set($data)->update();
    }
    
    /**
     * 
     */
    public function getRowCountWithCondition($table, $condition)
    {
        $builder = $this->db3->table($table);
        return $builder->where($condition)->countAllResults();
    }
    
    /* Get Today row count */
    public function getTodayRowCountWithCondition($table, $conditions) {
        $builder = $this->db3->table($table);
        $builder->where($conditions);
        $builder->where('DATE(created_at)', date('Y-m-d')); // Adding today's date condition
        return $builder->countAllResults();
    }

    
}
