<?php
namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\Config\Services;

class ApiKeyFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $apiKey = $request->getHeaderLine('x-api-key');

        // Check if API key is missing or invalid
        if (!$apiKey || $apiKey !== 'njksdh766juyu76nb5t4u766455yuthy6ds5yfnhtasdftuthy6') {
            $response = Services::response();
            return $response->setStatusCode(401)
                ->setJSON(['status' => 'error', 'message' => 'Unauthorized: API key is missing or invalid.']);
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // No action needed after
    }
}

