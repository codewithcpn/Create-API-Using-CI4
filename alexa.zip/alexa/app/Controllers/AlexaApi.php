<?php
namespace App\Controllers;
use App\Models\AlexaModel;
use CodeIgniter\RESTful\ResourceController;
class AlexaApi extends ResourceController
{
    protected $format = 'json'; // Response format
    private $api_key = 'njksdh766juyu76nb5t4u766455yuthy6ds5yfnhtasdftuthy6'; // Your API key

 
// User Login
public function userLogin() {
    // Check if API Key is passed in the header
    $apiKey = $this->request->getHeaderLine('x-api-key');
    if (!$apiKey || $apiKey !== $this->api_key) {
        return $this->respond([
            'status'  => "F",
            'message' => 'API Key is required or invalid!',
            'data'    => '',
        ], 200);
    }

    // Get the input value from the POST request
    $emailId = $this->request->getPost('email_id');

    // Define the validation rules
    $rules = [
        'email_id' => 'required|valid_email|max_length[120]', // Email validation rules
    ];

    // Validate the input
    if (!$this->validate($rules)) {
        return $this->respond([
            'status'  => "F",
            'message' => 'Validation failed!',
            'errors'  => $this->validator->getErrors(),
        ]);
    }

    // Load the database connection
    $db = \Config\Database::connect();

    // Check if the email exists in the 'users' table
    $query = $db->table('users')
                ->select('*')
                ->where('email_id', $emailId)
                ->get();

    // Generate OTP and send email (Regardless of user existence)
    $otp = rand(100000, 999999);  // Generate a 6-digit OTP

    // Store OTP with expiration (2 minutes validity)
    $otpData = [
        'otp'         => $otp,
        'expires_at'  => date('Y-m-d H:i:s', strtotime('+2 minutes')), // Set expiration time
    ];

    if ($query->getNumRows() > 0) {
        // If the user exists, update the OTP and expiration time
        $db->table('users')
           ->where('email_id', $emailId)
           ->update($otpData);
    } else {
        // If the user doesn't exist, insert user and OTP data
        $userData = [
            'email_id'    => $emailId, // Only email_id initially
            'otp'         => $otp,
            'expires_at'  => date('Y-m-d H:i:s', strtotime('+2 minutes')), // Set expiration time
        ];
        $db->table('users')->insert($userData);
    }

    // Send OTP via email
    $emailMessage = "Your OTP is: $otp\nIt will be valid for 2 minutes.";
    $emailSubject = "Your OTP Code";

    // Use CodeIgniter's Email library to send OTP
    $email = \Config\Services::email();
    $email->setFrom('your_email@example.com', 'Your App Name');
    $email->setTo($emailId);
    $email->setSubject($emailSubject);
    $email->setMessage($emailMessage);
    $email->send();

    return $this->respond([
        'status'  => "S",
        'message' => 'OTP sent for verification.',
        'type'    => "N", // Type N to signify email not yet verified.
        'data'    => '',
    ]);
}

// Login OTP Verification
public function loginVerifyOtp() {
    // Check if API Key is passed in the header
    $apiKey = $this->request->getHeaderLine('x-api-key');
    if (!$apiKey || $apiKey !== $this->api_key) {
        return $this->respond([
            'status'  => "F",
            'message' => 'API Key is required or invalid!',
            'data'    => '',
        ], 200); // Status 200 as per your requirement
    }

    // Get the OTP from the POST request
    $otp = $this->request->getPost('otp');  // Capture OTP for verification

    // Define the validation rules
    $rules = [
        'otp' => 'required|exact_length[6]', // OTP validation rule (should be exactly 6 digits)
    ];

    // Validate the input
    if (!$this->validate($rules)) {
        return $this->respond([
            'status'  => "F",
            'message' => 'Validation failed!',
            'errors'  => $this->validator->getErrors(),
        ]);
    }

    // Load the database connection
    $db = \Config\Database::connect();

    // Check if the OTP exists and is not expired in the 'users' table
    $query = $db->table('users')
                ->select('*')
                ->where('otp', $otp)
                ->where('expires_at >=', date('Y-m-d H:i:s'))  // Ensure OTP is not expired
                ->get();

    // If OTP does not match or has expired
    if ($query->getNumRows() == 0) {
        return $this->respond([
            'status'  => "F",
            'type'    => "N",
            'message' => 'Invalid or expired OTP!',
            'data'    => '',
        ]);
    }

    // OTP is valid, extract email_id from users table
    $otpData = $query->getRow();
    $emailId = $otpData->email_id;  // Extract email_id from OTP data

    // Check if the user exists and verify full_name
    $userQuery = $db->table('users')
                    ->select('*')
                    ->where('email_id', $emailId)
                    ->get();

    // If user exists, check for full_name
    if ($userQuery->getNumRows() > 0) {
        $userRecord = $userQuery->getRow();
        $statusType = $userRecord->full_name ? 'Y' : 'N'; // If full_name exists, return Y else N

        return $this->respond([
            'status'  => "S",
            'type'    => $statusType, // Return Y or N based on full_name existence
            'message' => 'OTP Verified!',
            'data'    => [
                'user_id' => $userRecord->id,
                'email_id' => $userRecord->email_id,
                'full_name' => $userRecord->full_name,
            ],
        ]);
    } else {
        return $this->respond([
            'status'  => "F",
            'type'    => "N", // If user does not exist
            'message' => 'No user found with this email!',
            'data'    => '',
        ]);
    }
}

// User Profile API
public function getUserProfile() {
    // Check if API Key is passed in the header
    $apiKey = $this->request->getHeaderLine('x-api-key');
    if (!$apiKey || $apiKey !== $this->api_key) {
        return $this->respond([
            'status'  => "F",
            'message' => 'API Key is required or invalid!',
            'data'    => '',
        ], 200);
    }

    // Get the user_id from the POST request
    $userId = $this->request->getPost('user_id');

    // Define the validation rules for user_id
    $rules = [
        'user_id' => 'required|numeric', // Ensure user_id is provided and is a number
    ];

    // Validate the input
    if (!$this->validate($rules)) {
        return $this->respond([
            'status'  => "F",
            'message' => 'Validation failed!',
            'errors'  => $this->validator->getErrors(),
        ]);
    }

    // Load the database connection
    $db = \Config\Database::connect();

    // Fetch the user details from the 'users' table using user_id
    $query = $db->table('users')
                ->select('id, full_name, email_id, phone_no, otp, expires_at, created_at')
                ->where('id', $userId)
                ->get();

    // Check if user exists
    if ($query->getNumRows() > 0) {
        // User data found, return user profile details
        $userRecord = $query->getRow();

        return $this->respond([
            'status'  => "S",
            'message' => 'User profile fetched successfully.',
            'data'    => [
                'user_id'    => $userRecord->id,
                'full_name'  => $userRecord->full_name,
                'email_id'   => $userRecord->email_id,
                'phone_no'   => $userRecord->phone_no,
                'otp'        => $userRecord->otp,
                'expires_at' => $userRecord->expires_at,
                'created_at' => $userRecord->created_at,
                // 'updated_at' => $userRecord->updated_at,
            ],
        ]);
    } else {
        // If user does not exist with that ID
        return $this->respond([
            'status'  => "F",
            'message' => 'User not found!',
            'data'    => '',
        ]);
    }
}



// Profile Update API
public function updateProfile() {
    // Check if API Key is passed in the header
    $apiKey = $this->request->getHeaderLine('x-api-key');
    if (!$apiKey || $apiKey !== $this->api_key) {
        return $this->respond([
            'status'  => "F",
            'message' => 'API Key is required or invalid!',
            'data'    => '',
        ], 200); // Status 200 as per your requirement
    }

    // Get the input values from the POST request
    $userId = $this->request->getPost('user_id');
    $fullName = $this->request->getPost('full_name');

    // Define the validation rules
    $rules = [
        'user_id'   => 'required|numeric',          // user_id must be provided and numeric
        'full_name' => 'required|max_length[120]',  // full_name must be provided and less than or equal to 120 characters
    ];

    // Validate the input
    if (!$this->validate($rules)) {
        return $this->respond([
            'status'  => "F",
            'message' => 'Validation failed!',
            'errors'  => $this->validator->getErrors(),
        ]);
    }

    // Load the database connection
    $db = \Config\Database::connect();

    // Check if the user exists in the 'users' table
    $query = $db->table('users')
                ->select('*')
                ->where('id', $userId)
                ->get();

    // If user does not exist
    if ($query->getNumRows() == 0) {
        return $this->respond([
            'status'  => "F",
            'message' => 'User not found!',
            'data'    => '',
        ]);
    }

    // Update the user's name in the 'users' table
    $updateData = [
        'full_name' => $fullName, // New full name to update
    ];

    // Perform the update operation
    $updateQuery = $db->table('users')
                      ->where('id', $userId)
                      ->update($updateData);

    // If the update is successful
    if ($updateQuery) {
        return $this->respond([
            'status'  => "S",
            'message' => 'Profile updated successfully!',
            'data'    => [
                'user_id'   => $userId,
                'full_name' => $fullName,
            ],
        ]);
    } else {
        // If the update failed
        return $this->respond([
            'status'  => "F",
            'message' => 'Failed to update profile. Please try again later.',
            'data'    => '',
        ]);
    }
}



    
    







}