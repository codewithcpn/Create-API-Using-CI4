<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');


/*************************************
 API Routes
*************************************/
$routes->group('api', ['filter' => 'api_key'], function ($routes) {   
    
    
    // User Login
    $routes->post('user-login', 'AlexaApi::userLogin');
    $routes->post('user-login-verify-otp', 'AlexaApi::loginVerifyOtp'); 

    // Profile
    $routes->post('update-profile', 'AlexaApi::updateProfile');
    $routes->post('get-user-profile', 'AlexaApi::getUserProfile');
    
});

